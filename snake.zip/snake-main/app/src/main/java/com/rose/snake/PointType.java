package com.rose.snake;

public enum PointType {
    EMPTY, SNAKE, APPLE
}
