package com.rose.snake;

public enum Direction {
    LEFT, RIGHT, UP, DOWN
}
