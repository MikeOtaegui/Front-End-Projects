package com.rose.snake;

public interface ScoreUpdatedListener {
    void onScoreUpdated(int score);
}
