package com.rose.tetris.presenter;

public interface PresenterCompletableObserver {
    void onNext();
}
