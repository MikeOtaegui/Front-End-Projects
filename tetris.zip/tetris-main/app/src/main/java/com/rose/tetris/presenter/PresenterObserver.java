package com.rose.tetris.presenter;

public interface PresenterObserver<T> {
    void observe(T t);
}
