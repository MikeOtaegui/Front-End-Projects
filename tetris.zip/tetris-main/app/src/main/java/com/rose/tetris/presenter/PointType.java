package com.rose.tetris.presenter;

public enum PointType {
    EMPTY, BOX, VERTICAL_LINE, HORIZONTAL_LINE
}
