package com.rose.tetris.presenter;

public enum GameTurn {
    LEFT, RIGHT, UP, DOWN, FIRE
}
